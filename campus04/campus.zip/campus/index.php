<!DOCTYPE html>
	<head>
		<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  		<link rel="stylesheet" type="text/css" href="new.css">
  		<link href="css/global.css" type="text/css" rel="stylesheet">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
		<div class="bgimage">
			<div class="container-fluid"><br>
				<div class="css3-notification">
					<label> KIT's College of Engineering, Kolhapur </label>
					<label> Campus Recruitment System </label>
				</div>
				<br><br><br><br>
				<div class="col-md-1"></div>
				<div class="col-md-5 slidead">
					<center><a href="nextadmin.php"><div class="slideadh"><img src="manager.png" height="200" width="200"><br><br><label class="designi"> Admin</label></div></a></center><br>
				</div>
				<div class="col-md-5 slidest">
					<center><a href="nextstudent.php"><div class="slidesth"><img src="student.png" height="200" width="200"><br><br><label class="designi"> Student</label></div></a></center><br>
				</div>
				<div class="col-md-1"></div>
			</div>
		</div>
	</body>
</html>